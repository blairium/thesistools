# thesistools/plotting.py
"""_summary_
A collection of plotting tools for the Latex Thesis template
Author: Blair Haydon 2025
"""

from __future__ import annotations
from string import ascii_lowercase
import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass


@dataclass
class panel_labeller:
    """
    Class for generating sequential labels for plot panels.
    """

    sequence: str = ascii_lowercase
    _label_index: int = 0

    def next(self) -> str:
        """
        Get the next label in the sequence.
        Returns:
            str: The next label.
        """
        label = self.sequence[self._label_index]
        self._label_index += 1
        return label


def add_subfig_label(
    ax, label: str, facecolor="0.7", edgecolor="none", alpha=0.5, *args, **kwargs
):
    """
    Add a label to a subfigure.

    Parameters:
        ax (mpl.axes.Axes): The subplot axis to label.
        label (str): The label text.
        description (str, optional): Additional description text.
    """
    ax.set_ybound(upper=ax.get_ybound()[1] * 1.05)
    ax.annotate(
        f"({label})",
        xy=(0, 1),
        xycoords="axes fraction",
        xytext=(+0.5, -0.5),
        textcoords="offset fontsize",
        fontsize="medium",
        verticalalignment="top",
        fontfamily="serif",
        bbox=dict(
            facecolor=facecolor,
            edgecolor=edgecolor,
            pad=3.0,
            alpha=alpha,
            *args,
            **kwargs,
        ),
    )


def set_size(aspect: float | str = "wide"):
    """Set figure dimensions to avoid scaling in LaTeX.

    Parameters
    ----------
    width: float
            Document textwidth or columnwidth in pts
    fraction: float, optional
            Fraction of the width which you wish the figure to occupy

    Returns
    -------
    fig_dim: tuple
            Dimensions of figure in inches
    """
    fig_width_pt: float = 438.17247  # pt
    inches_per_pt: float = 1 / 72.27
    golden_ratio: float = (5**0.5 - 1) / 2
    fig_width_in: float = fig_width_pt * inches_per_pt
    if aspect == "wide":
        fig_height_in: float = fig_width_in * golden_ratio
    elif aspect == "tall":
        fig_height_in: float = fig_width_in / golden_ratio
    elif type(aspect) in [float, int]:
        fig_height_in: float = fig_width_in * aspect
    else:
        fig_height_in: float = fig_width_in
    fig_dim: float = (fig_width_in, fig_height_in)

    return fig_dim


if __name__ == "__main__":
    x = np.linspace(0, 2 * np.pi, 50)

    ys = {"Sin(x)": np.sin(x), "Cos(x)": np.cos(x)}
    fig, axes = plt.subplots(1, 2)

    labeler = panel_labeller()

    for ax, (key, y) in zip(axes.flatten(), ys.items()):
        ax.plot(x, y)
        ax.set_title(key)
        ax.set_xlabel("x")
        ax.set_ylabel(key)
        add_subfig_label(ax, labeler.next())
    plt.tight_layout()
    plt.show()
